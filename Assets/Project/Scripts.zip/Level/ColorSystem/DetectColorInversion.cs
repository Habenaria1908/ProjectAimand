using UnityEditor;
using UnityEngine;



public class DetectColorInversion : MonoBehaviour, IEventListener<ColorInvertEvent>
{
    public enum ColorState
    {
        None,
        Normal,
        Invert,
        Half
    }

    [MyReadOnly]
    public bool currentInvertState;
    public ColorState state;

    [Header("설정")]
    public bool disableSpriteRenderer = false;
    public bool disableCollider = true;
    public bool disableDamageOnTouch = true;

    public bool enableSetting { get; private set; }
    public bool harfInverter { get; private set; }

    private Collider2D m_collider2D;
    private DamageOnTouch m_damageOnTouch;
    private SpriteRenderer m_spriteRenderer;
    private bool isPlayerInCollider;
    private int m_layer;
    private int m_ignoreRaycastLayer;



    private void Awake()
    {
        m_collider2D = GetComponent<Collider2D>();
        m_damageOnTouch = GetComponent<DamageOnTouch>();
        m_spriteRenderer = GetComponentInChildren<SpriteRenderer>();

        m_layer = this.gameObject.layer;
    }

    private void Start()
    {
        Initialization();
        m_ignoreRaycastLayer = 2;
    }

    private void Initialization()
    {
        if (m_damageOnTouch != null)
        {
            disableCollider = false;
        }

        if (state == ColorState.Half)
        {
            disableCollider = false;
            disableDamageOnTouch = false;
        }

        SetMaterial();
        SetCollider(currentInvertState);
    }

    private void Update()
    {
        if (isPlayerInCollider)
        {
            RaycastHit2D hit = MyDebug.BoxCast(transform.position, m_collider2D.bounds.size, 0f, Vector2.zero, 0f, LayerManager.playerLayerMask, Color.yellow, true);

            if (false == hit)
            {
                EnableSettings();
                isPlayerInCollider = false;
            }
        }
    }

    private void SetMaterial()
    {
        if (m_spriteRenderer != null)
        {
            switch (state)
            {
                case ColorState.Normal:
                    m_spriteRenderer.material = new Material(Shader.Find("Universal Render Pipeline/2D/Sprite-Lit-Default"));
                    currentInvertState = false;
                    break;

                case ColorState.Invert:
                    m_spriteRenderer.material = new Material(Shader.Find("Sprites/DotInvert"));
                    currentInvertState = true;
                    break;

                case ColorState.Half:
                    m_spriteRenderer.material = new Material(Shader.Find("Sprites/HalfDotInvert"));
                    currentInvertState = false;
                    break;

            }

            //if (false == m_spriteRenderer.material.name.Contains("ColorInversionMaterial"))
            //{
            //    m_spriteRenderer.material = Resources.Load<Material>("Shaders/Materials/ColorInversionMaterial");
            //}

            //float amount = m_material.GetFloat(InvertAmountID);

            //if (amount == 0)
            //{
            //    state = ColorState.Normal;
            //    m_material.SetFloat(InvertAmountID, 0);
            //}
            //else if (amount == 1)
            //{
            //    state = ColorState.Invert;
            //    m_material.SetFloat(InvertAmountID, 1);
            //}
            //else
            //{
            //    state = ColorState.None;
            //}
        }
    }

    private void SetCollider(bool _invert)
    {
        currentInvertState = _invert;

        if ((state == ColorState.Normal && false == _invert)
            || (state == ColorState.Invert && _invert))
        {
            Vector2 size = Vector2.zero;
            if (m_collider2D != null)
            {
                size = m_collider2D.bounds.size;
            }
           
            if (disableSpriteRenderer && MyDebug.BoxCast(transform.position, size, 0f, Vector2.zero, 0f, LayerManager.playerLayerMask, Color.yellow, true))
            {
                isPlayerInCollider = true;
                this.gameObject.layer = m_ignoreRaycastLayer;
            }
            else
            {
                EnableSettings();
            }
        }
        else
        {
            DisableSettings();
        }
    }

    private void EnableSettings()
    {
        if (disableSpriteRenderer && m_spriteRenderer != null)
        {
            m_spriteRenderer.enabled = true;
            this.gameObject.layer = m_layer;
        }

        if (disableCollider && m_collider2D != null)
        {
            m_collider2D.isTrigger = false;
        }

        if (false == disableSpriteRenderer &&
            disableDamageOnTouch && m_damageOnTouch != null)
        {
            m_damageOnTouch.enabled = true;
        }

        enableSetting = true;
    }

    private void DisableSettings()
    {
        isPlayerInCollider = false;

        if (disableSpriteRenderer && m_spriteRenderer != null)
        {
            m_spriteRenderer.enabled = false;
            this.gameObject.layer = m_ignoreRaycastLayer;
        }

        if (disableCollider && m_collider2D != null)
        {
            m_collider2D.isTrigger = true;
        }

        if (false == disableSpriteRenderer &&
            disableDamageOnTouch && m_damageOnTouch != null)
        {
            m_damageOnTouch.enabled = false;
        }

        enableSetting = false;
    }

    public void OnEvent(ColorInvertEvent e)
    {
        SetCollider(e.isInvert);
    }

    protected virtual void OnEnable()
    {
        this.EventStartListening<ColorInvertEvent>();
    }

    protected virtual void OnDisable()
    {
        this.EventStopListening<ColorInvertEvent>();
    }

#if UNITY_EDITOR
    private void OnDrawGizmos()
    {
        if (state == ColorState.None)
        {
            return;
        }

        if (state != ColorState.Half)
        {
            string text = state == ColorState.Normal ? "Normal" : "Invert";

            GUIStyle style = new GUIStyle();
            style.normal.textColor = state == ColorState.Normal ? Color.yellow : Color.blue;
            Handles.Label(transform.position + (Vector3.down * 0.4f) + (Vector3.right * 0.4f), text, style);
        }
    }

    private void Reset()
    {

    }

    private void OnValidate()
    {
        m_spriteRenderer = GetComponentInChildren<SpriteRenderer>();

        if (m_spriteRenderer != null)
        {
            switch (state)
            {
                case ColorState.Normal:
                    m_spriteRenderer.material = new Material(Shader.Find("Universal Render Pipeline/2D/Sprite-Lit-Default"));
                    break;

                case ColorState.Invert:
                    m_spriteRenderer.material = new Material(Shader.Find("Sprites/DotInvert"));
                    break;

                case ColorState.Half:
                    m_spriteRenderer.material = new Material(Shader.Find("Sprites/HalfDotInvert"));
                    break;
            }
        }
    }
#endif
}
